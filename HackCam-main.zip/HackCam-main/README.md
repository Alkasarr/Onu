# HackCam

Hack Android or Ios devices camera with a single phishing link using this awesome tool

<p align="center">
<a href="https://github.com/V1CK3Y2"><img title="Author" src="https://img.shields.io/badge/Author-V1CK3Y2-red.svg?style=for-the-badge&logo=github"></a>
<a href="Bash"><img title="5.1" src="https://img.shields.io/badge/Bash-5.1-lightgreen.svg?style=for-the-badge&logo=bash"></a>
</p>

### Features:

#### Works for Android and iPhone
#### 100% working phishing pages
#### Ngrok port forwarding

## Legal disclaimer:

Usage of HackCam for attacking targets without prior mutual consent is illegal. It's the end user's responsibility to obey all applicable local, state and federal laws. Developers assume no liability and are not responsible for any misuse or damage caused by this program. 

### Usage:
```
git clone https://github.com/V1CK3Y2/HackCam
cd HackCam
ls
chmod 777 hackcam.sh
bash hackcam.sh.sh
```
## HackCam in Terminal

[![Screenshot-2020-12-01-23-47-35-1.png](https://i.postimg.cc/76fMXdL5/Screenshot-2020-12-01-23-47-35-1.png)](https://postimg.cc/34QvxLmh)

<p>
<img src="https://visitor-badge.laobi.icu/badge?page_id=JasonJerry.lockphish" alt="visitor badge"/>
</p>
